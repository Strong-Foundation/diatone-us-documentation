                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3350423
Diatone GT M - Parts / Gopro Session Mounts 25,35,60 by William_Shea_brown is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Here is a compleat set of parts for the Diatone GT series of drones. Everything you may need to trick out and protect your GT. I have also provided the original SolidWorks files so you can modify the models to suit your own application. 

The Gopro Session mounts are 25, 35 and 60 degrees. There are two fin styles. Also motor/frame arm protectors along with motor protectors. The flight control side covers are available from another creator on here (Diatone GT-M addons by slibbinas). I have provided them here with my designs but please give credit to Slibbinas for these specific design. Here is a link to his project. 

https://www.thingiverse.com/thing:2822329


# Print Settings

Rafts: Doesn't Matter
Supports: Yes
Resolution: 0.1
Infill: 20
Filament_brand: NA
Filament_material: PLA

Notes: 
Some of these models will require supports for printing. The gopro mounts are best printed on there right (Flat) side. I have achieved the best results in printing them this way.