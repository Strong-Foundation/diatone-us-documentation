                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3268709
Diatone GT-R90 POD/canopy by evret is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

POD/canopy for Diatone GT-R90 with areas designed to fit whip antenna in the ridge and a Capacitor in the back to stop video noise (i use 24v 220uf low esr)
this was designed for original version gtr90, i think later ones come with a filter board to fix video noise.
not suitable for standard PLA due to separation issues near mount holes.
We only use Polymaker Polymax PLA for pods (even on 5" quads)
not sure how it would go in TPU, please let me know if you try it.
lastly, this version is designed to suit a camera with longer lens then the default GT-R90 camera (i'm using runcam micro swift 2), i'll try to add another version for default cam when i get the chance


# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Infill: 20%
Filament_brand: polymaker
Filament_material: polymax