                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3317546
Diatone 2019 R349, R249 & R239 - 45 Degree VTX Antenna Mount (Turtle Mode Friendly) by ninova66 is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Created this for my new Diatone 2019 R349, but it should work for the R239 and R249 since it uses the same canopy. I saw a bunch of YouTube reviews and they all complained about the antenna placement so I created this as fix for that issue. Also it will come in handy for turtle mode too!

This was designed to be printed in TPU. I don't think it will work at all in any other material plus it would break in a crash and ruin your antenna so I would highly recommend not printing it in any other material except Flexible filaments like TPU.

So to avoid using supports I created this into two sections the stand and the fin section. The fin has some blocks on the side that are meant to support the piece as it printed, so it needs to be cut off after it's printed. After you cut off the block I found the best way to join the two pieces with a hot soldering iron. I purposely added 2mm to the bottom of the fin to melt and join the two pieces together. After that all you need to do is secure everything with 3 zip ties.

Hope you enjoy it.

Link to the TBS Crossfire Antenna Mount that I also made: https://www.thingiverse.com/thing:3317512

Link to a leveling stand to calibrate your Accelerometer if you need it: https://www.thingiverse.com/thing:3319293