                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3191049
Diatone Caddx Turtle V2 Back Pack by WyreUK is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

So I wanted to put a Caddx Turtle V2 on to my Diatone GT-M515, but of course there is no space for it inside the frame, I looked on here and no one had done it yet, so that meant a trip into SketchUp. Here is the result. It works, I'm not happy with the look of the top piece and I will be designing a V2, I've just got a copy of Fusion 360, so I will be able to do more lol
It is printed in PLA and I printed it in orange as it has the biggest contrast with the green of the grass and bushes, hence it should be easier to find when I crash lol.

I've put up the SketchUp file so that anyone can have a go at changing it for the better, but if you want to sell this then I ask that you contact me first please.

If you would like one and don't have a printer then please contact me and I'll print you one off, for a very small fee and you cover postage.

# Print Settings

Printer Brand: Anet
Printer: A8
Rafts: No
Supports: Yes
Resolution: 0.15
Infill: 20%
Filament_brand: Generic
Filament_color: Any you want But orange is the best contrastto green, that or pink! lol
Filament_material: PLA, ABS

Notes: 
I did use a brim but its not necessary. 

# Post-Printing

Not much post printing needed, a quick sand around the edges and that's it.

All hardware needed are M2 

There is space underneath the base plate  defined for a piece of foam to help reduce wind noise on the microphone!

# How I Designed This

The design concept for this was to make it as low as possible whilst still being able to access everything, like the SD card holder and such. But also I wanted to keep the mic out of the way and to protect the cables. So I designed it so that the cables run up the inside and underneath the mount and come up from the back, hopefully keeping them safe.