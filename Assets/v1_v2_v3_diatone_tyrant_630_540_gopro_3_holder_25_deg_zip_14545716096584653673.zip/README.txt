                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3308912
V1 + V2 + V3 Diatone Tyrant 630 / 540 Gopro 3 holder (25 deg) by Lennson is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

UPDATED VERSION 2/3

Mount for Diatone Tyrant 630 ,540, and 530 with an angle of 25 deg.

V1 its too bouncy/flexible!! / dont waste time and filament
V2 is much better. More Gopro contact surface and more stable with almost same weight.
V3 is same design as V2 but mounted with zipties (max 2x4mm)

Gopro is clear and "out of danger" with 5 and 6 inch props.
mass:    ~20g with support
              ~16g without support

Print in TPU / Ninjaflex with 30% and 2 perimeter.
Print with support
print all fans allways on. cant get too much air 

FFF profile is in the download section

my tpu print settings on CTC Bizer MK10




----General settings----
retraction  distance       : 1.5mm               (UPDATED!)
retraction speed           : 25mm/s              (UPDATED!)
nozzlediameter            : 0.4mm
layer height                  :0,15mm
Solid top/bottom layer : 5                          (UPDATED!)
perimeter                    : 2
infill pattern : FULL HONEYCOMP           (UPDATED!)
external fill pattern: rectilinear
overlap: 11 %
minimum infill length     : 0.1mm

----Support----
suport infill                    : 17%
extra inflation distance :1.6mm
dense support layer      :3
dense infill percentage :65%
horizontal offset            :0.2mm

----Temp----
Table : ABS Juice (thin film DOOOONT touch it!!!)
Extruder Temp: 230 deg
Table temp: 0 (not powerd/ room temp / 25 deg)

---- FANs----
all full power always.
yes also the first layer :-)

----Speeds----
general speed   : 37mm/s                         (UPDATED!)
outline               :60%
infill                    :100%
support              : 80%
x/y axis moove   :150mm/s
z axis moove      :22.5mm/s

---Other---
extra inflation distance :5sq/mm
bridging speed/extrusion : 100%
Allow singe extrusion INTERNAL + EXTERNAL infill
allowed perimeter overlap 50% 
minimum travel for retraction 1.0mm