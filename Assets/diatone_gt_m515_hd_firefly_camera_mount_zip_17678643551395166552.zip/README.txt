                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3119460
Diatone GT-M515 HD Firefly Camera Mount  by WyreUK is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Hi Folks,

Here we have a Hawkeye Firefly Micro HD Camera Mount for the Diatone GT-M515, though it will fit most Diatone models as the cage on them seems to be the same size and has the same fixings.

THe holder frame I have printed in PLA though you could print it in any filament you choose. The holder itself is to be printed in TPU. I have included two different holders, one with a gap in the top and a solid one. I haven't tested the one with the gap. The solid one fits the Micro snuggly and holds it really nicely. I have also made sure that the SD Card cannot be ejected in the event of a crash. I've lost a few cards that way lol.

I have also included the Sketchup file so that anyone can take this and modify it as is needed.

As you can see from the pictures I am in the middle of designing a TPU antenna mount for the back of this frame. I will publish this separately as soon as I'm happy with the design.

As you can see from the picture if you want to prototype then be prepared to use a lot of material lol

Please be aware that if you intend to make money of this model then you will have to contact me first to obtain my permission. 

# Post-Printing

Additional Hardware:

You will need some additional hardware to attach this mount.

2x 19mm x 3.5mm M2 Standoffs
2x 6mm M2 Hex bolts
2x 10mm M2 Hex bolts
2x M3 Nylon Washers